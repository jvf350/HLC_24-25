package com.example.streamifyapp.models

import com.example.streamifyapp.R

class Articulos {

    companion object {
        val lista: MutableList<Articulo> = mutableListOf()


        fun filtrarArticulosPorCategoria(categoriaId: Int): List<Articulo>{

            val filteredItems = lista.filter {
                (it.categoriaId .equals(categoriaId))
            }

            return filteredItems
        }

        fun filtrarArticulos(productId: Int): List<Articulo>{

            val filteredItems = lista.filter {
                (it.id.equals(productId))
            }

            return filteredItems
        }

        fun cargar() {

            if (Articulos.lista.isEmpty()) {

                lista.add(
                    Articulo(
                        1,
                        "El señor de los anillos",
                        1,
                        "En la Tierra Media, el Señor Oscuro Sauron forjó los Grandes Anillos del Poder y creó uno con el poder de esclavizar a toda la Tierra Media. Frodo Bolsón es un hobbit al que su tío Bilbo hace portador del poderoso Anillo Único con la misión de destruirlo. Acompañado de sus amigos, Frodo emprende un viaje hacia Mordor, el único lugar donde el anillo puede ser destruido. Sin embargo, Sauron ordena la persecución del grupo para recuperar el anillo y acabar con la Tierra Media.",
                        5.0f,
                        R.drawable.pelicula_senoranillos1
                    )
                )

                lista.add(
                    Articulo(
                        2,
                        "El Padrino",
                        1,
                        "Don Vito Corleone, el patriarca de una poderosa familia mafiosa en Nueva York, intenta traspasar el liderazgo de la organización a su hijo Michael, quien al principio se resiste, pero poco a poco es absorbido por el mundo del crimen.",
                        4.4f,
                        R.drawable.pelicula_padrino
                    )
                )

                lista.add(
                    Articulo(
                        3,
                        "Star Wars: Una nueva esperanza",
                        2,
                        "La Alianza Rebelde, liderada por la princesa Leia, está en guerra contra el malvado Imperio Galáctico. Luke Skywalker se une a la lucha para salvar la galaxia, ayudado por el jedi Obi-Wan Kenobi y otros héroes.",
                        4.0f,
                        R.drawable.pelicula_starwars
                    )
                )

                lista.add(
                    Articulo(
                        4,
                        "Matrix",
                        3,
                        "Neo, un programador de software, descubre la verdad detrás de la realidad: el mundo es una simulación creada por máquinas para controlar a los humanos. Se une a la rebelión para liberar a la humanidad.",
                        4.5f,
                        R.drawable.pelicula_matrix
                    )
                )

                lista.add(
                    Articulo(
                        5,
                        "Titanic",
                        4,
                        "Una historia de amor entre Jack y Rose, dos jóvenes de diferentes clases sociales, a bordo del Titanic, el famoso barco que se hundió en su viaje inaugural en 1912.",
                        3.6f,
                        R.drawable.pelicula_titanic
                    )
                )

                lista.add(Articulo(6, "Gladiador", 5, "Máximo, un general romano, es traicionado y vendido como esclavo. Se convierte en gladiador y lucha para vengarse del emperador que lo traicionó.",
                    4.7f, R.drawable.pelicula_gladiador))

                lista.add(Articulo(7, "Inception", 6, "Dom Cobb es un ladrón que tiene la habilidad de entrar en los sueños de las personas y robar sus secretos. Es contratado para realizar una tarea casi imposible: implantar una idea en lugar de robarla.",
                    4.8f, R.drawable.pelicula_inception))

                lista.add(Articulo(8, "El caballero oscuro", 1, "Batman enfrenta al Joker, un criminal caótico que siembra el terror en Gotham City. Con la ayuda de Harvey Dent y James Gordon, lucha para salvar la ciudad del caos total.",
                    4.9f, R.drawable.pelicula_caballero_oscuro))

                lista.add(Articulo(9, "Forrest Gump", 7, "Forrest Gump, un hombre con una inteligencia limitada pero un corazón de oro, experimenta eventos históricos importantes mientras busca a su amada Jenny.",
                    4.7f, R.drawable.pelicula_forrest_gump))

                lista.add(Articulo(10, "Jurassic Park", 1, "Un parque temático con dinosaurios clonados se convierte en un caos cuando las criaturas se liberan y comienzan a cazar a los visitantes.",
                    4.6f, R.drawable.pelicula_jurassic_park))

                lista.add(Articulo(11, "Avatar", 1, "Jake Sully, un ex-marine, se infiltra en el mundo de Pandora para extraer recursos, pero se une a los nativos Na'vi en su lucha contra los invasores humanos.",
                    4.5f, R.drawable.pelicula_avatar))

                lista.add(Articulo(12, "El silencio de los inocentes", 2, "Clarice Starling, una joven agente del FBI, debe confiar en un asesino caníbal encarcelado, el Dr. Hannibal Lecter, para atrapar a otro asesino en serie.",
                    4.8f, R.drawable.pelicula_silencio_corderos))

                lista.add(Articulo(13, "La lista de Schindler", 2, "La historia de Oskar Schindler, un empresario alemán que salvó la vida de más de mil judíos durante el Holocausto al emplearlos en su fábrica.",
                    4.9f, R.drawable.pelicula_lista_schindler))

                lista.add(Articulo(14, "El resplandor", 3, "Jack Torrance, un aspirante a escritor, se convierte en el cuidador de un hotel aislado en invierno, donde se ve influenciado por fuerzas sobrenaturales que lo empujan a la locura.",
                    4.7f, R.drawable.pelicula_resplandor))

                lista.add(Articulo(15, "Pulp Fiction", 1, "Una serie de historias entrelazadas de crimen y redención que siguen a personajes como Vincent Vega, Jules Winnfield, y la esposa de un gánster, Mia Wallace.",
                    4.8f, R.drawable.pelicula_pulp_fiction))

                lista.add(Articulo(16, "Avengers: Endgame", 2, "Los Vengadores se reúnen para revertir el daño causado por Thanos en la batalla final que decidirá el destino del universo.",
                    4.7f, R.drawable.pelicula_avenger_endgame))

                lista.add(Articulo(17, "Regreso al futuro", 3, "Marty McFly, un adolescente de los años 80, viaja accidentalmente al pasado en un DeLorean modificado por el excéntrico científico Doc Brown.",
                    4.7f, R.drawable.pelicula_regreso_futuro))

                lista.add(Articulo(18, "El bueno, el feo y el malo", 3, "Tres hombres compiten para encontrar un tesoro escondido durante la Guerra Civil estadounidense en un western clásico lleno de suspenso y acción.",
                    4.8f, R.drawable.pelicula_bueno_feo_malo))

                lista.add(Articulo(19, "Blade Runner", 3, "En un futuro distópico, un cazador de replicantes llamado Deckard debe retirar a varios androides que han escapado a la Tierra.",
                    4.6f, R.drawable.pelicula_blade_runner))

                lista.add(Articulo(20, "La guerra de los mundos", 1, "Una invasión alienígena amenaza con destruir la humanidad mientras una familia lucha por sobrevivir en medio del caos.",
                    4.5f, R.drawable.pelicula_guerra_mundos))

            }

        }

    }

}