package com.example.streamifyapp.models

import java.util.stream.Collectors

class Usuarios() {

    companion object {
        val lista: MutableList<Usuario> = mutableListOf()

        fun insertar(item: Usuario): Boolean{

            val filteredItems = lista.filter {
                ((it.email.equals(item.email)) && (it.password.equals(item.password)))
            }

            if (filteredItems.isEmpty())
                return lista.add(item)
            else
                return false

        }


        fun cargar() {

            if (lista.isEmpty())
                //Cargamos en la lista un usuario por defecto
                lista.add(Usuario("usuario", "usuario@gmail.com", "1234", "950114477"))

        }

        fun validarPassword(email: String?, password: String?): Boolean {

            val filteredItems = lista.filter {
                ((it.email.equals(email)) && (it.password.equals(password)))

            }

            return !filteredItems.isEmpty()


        }



    }

}

