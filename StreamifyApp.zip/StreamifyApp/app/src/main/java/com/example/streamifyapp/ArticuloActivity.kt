package com.example.streamifyapp

import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.streamifyapp.models.Articulos
import java.lang.String

class ArticuloActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_articulo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        val intent = intent
        val productId = intent.getIntExtra("productId", 0)
        val item = Articulos.filtrarArticulos(productId).first()

        val nombre = findViewById<TextView>(R.id.tvNombre)
        val descripcion = findViewById<TextView>(R.id.tvDescripcion)
        val valoracion = findViewById<RatingBar>(R.id.ratingBar)
        val imagen = findViewById<ImageView>(R.id.ivImagen)


        nombre.setText(item.nombre)
        descripcion.setText(item.descripcion)
        valoracion.rating = item.valoracion
        imagen.setImageResource(item.imageId)


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }

        }
        return true

    }
}