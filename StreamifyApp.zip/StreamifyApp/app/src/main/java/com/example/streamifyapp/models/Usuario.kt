package com.example.streamifyapp.models
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Usuario(val login: String, val email: String, val password: String, val telefono: String): Parcelable