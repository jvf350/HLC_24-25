package com.example.streamifyapp.models

import com.example.streamifyapp.R

class Categorias {

    companion object {
        val lista: MutableList<Categoria> = mutableListOf()


        fun cargar() {

            lista.add(Categoria(1, "Netflix", R.drawable.streaming_netflix))
            lista.add(Categoria(2, "HBO", R.drawable.streaming_max))
            lista.add(Categoria(3, "Disney+", R.drawable.streaming_disney))
            lista.add(Categoria(4, "Amazon Prime", R.drawable.streaming_primevideo))
            lista.add(Categoria(5, "DAZN", R.drawable.streaming_dazn))
            lista.add(Categoria(6, "Movistar TV", R.drawable.streaming_movistar))
            lista.add(Categoria(7, "Vodafone TV", R.drawable.streaming_vodafonetv))

        }


    }

}