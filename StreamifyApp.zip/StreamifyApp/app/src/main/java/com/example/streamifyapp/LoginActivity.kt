package com.example.streamifyapp

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.streamifyapp.models.Usuarios

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }




        val bIniciar = findViewById<Button>(R.id.bIniciar)
        bIniciar.setOnClickListener {
            validarLogin()
        }

        val bRegistrar = findViewById<TextView>(R.id.tvRegistrarse)
        bRegistrar.setOnClickListener {
            abrirRegistro()
        }

    }

    fun validarLogin() {
        val email = findViewById<TextView>(R.id.etEmail)
        val password = findViewById<TextView>(R.id.etPassword)
        var bOK = true

        if (TextUtils.isEmpty(email.text)) {
            email.error = resources.getString(R.string.requerido)
            bOK = false
        }
        if (TextUtils.isEmpty(password.text)) {
            password.error = resources.getString(R.string.requerido)
            bOK = false
        }

        if (bOK) {

            if (Usuarios.validarPassword(email.text.toString(), password.text.toString())) {
                val intent = Intent(this, CategoriasActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, R.string.errorlogin, Toast.LENGTH_SHORT).show()
            }

        }

    }

    fun abrirRegistro() {
        val intent = Intent(this, RegistroActivity::class.java)
        startActivity(intent)
    }

}