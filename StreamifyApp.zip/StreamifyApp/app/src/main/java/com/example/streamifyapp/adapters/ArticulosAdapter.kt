package com.example.streamifyapp.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.streamifyapp.R
import com.example.streamifyapp.models.Articulo

class ArticulosAdapter (
    private val context: Context,
    private val dataset: List<Articulo>,
    private val onItemClick: (Articulo) -> Unit
) : RecyclerView.Adapter<ArticulosAdapter.ItemViewHolder>() {


    class ItemViewHolder(private val view: View,
                         onItemClick: (value: Int) -> Unit) : RecyclerView.ViewHolder(view) {
        val tvNombre: TextView = view.findViewById(R.id.tvNombre)
        val imageView: ImageView = view.findViewById(R.id.imageView)
        val ratingBar: RatingBar = view.findViewById(R.id.ratingBar)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        // create a new view
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.rec_item_articulos, parent, false)

        return ItemViewHolder(adapterLayout) {
            onItemClick(dataset[it])
        }

    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]

        holder.tvNombre.text = item.nombre
        holder.ratingBar.rating = item.valoracion
        holder.imageView.setImageResource(item.imageId)

        holder.itemView.setOnClickListener { onItemClick(item) }
    }

    override fun getItemCount() = dataset.size
}