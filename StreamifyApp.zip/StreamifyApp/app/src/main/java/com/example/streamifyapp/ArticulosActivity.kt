package com.example.streamifyapp

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.streamifyapp.adapters.ArticulosAdapter
import com.example.streamifyapp.models.Articulos


class ArticulosActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_articulos)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)




        //Cargamos la lista de artículos en memoría
        Articulos.cargar()

        //Filtramos los artículos de la categoría recibida
        val intent = intent
        val categoriaId = intent.getIntExtra("categoriaId", 0)
        val lista = Articulos.filtrarArticulosPorCategoria(categoriaId)
        val datos = lista

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        //Una lista vertical
        //val lmg = LinearLayoutManager(this,  LinearLayoutManager.VERTICAL, false)
        //recyclerView.layoutManager = lmg

        //Una vista en formato de cuadrícula con 3 columnas
        val gmg = GridLayoutManager(this,3)
        recyclerView.layoutManager = gmg


        val adaptador = ArticulosAdapter(this, datos) { model ->
            cargarArticulo(model.id)
        }

        recyclerView.adapter = adaptador

    }

    fun cargarArticulo(id: Int) {
        val intent = Intent(this, ArticuloActivity::class.java)
        intent.putExtra("productId", id)
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }

        }
        return true

    }



}