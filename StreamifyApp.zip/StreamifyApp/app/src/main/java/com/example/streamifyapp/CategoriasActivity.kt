package com.example.streamifyapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.streamifyapp.adapters.CategoriasAdapter
import com.example.streamifyapp.models.Categorias

class CategoriasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_categorias)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        //Cargamos la lista de categorías en memoria
        Categorias.cargar()
        val datos = Categorias.lista

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val lmg = LinearLayoutManager(this,  LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = lmg


        val adaptador = CategoriasAdapter(this, datos) { model ->
            cargarArticulos(model.id)
        }

        recyclerView.adapter = adaptador

    }

    fun cargarArticulos(id: Int) {
        val intent = Intent(this, ArticulosActivity::class.java)
        intent.putExtra("categoriaId", id)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_principal, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.menu_ayuda -> {
                val intent = Intent(this, AyudaActivity::class.java)
                startActivity(intent)
            }

            R.id.menu_acercade -> {
                val intent = Intent(this, AcercaActivity::class.java)
                startActivity(intent)
            }
            android.R.id.home -> {

                finish()
            }


        }
        return true

    }

}