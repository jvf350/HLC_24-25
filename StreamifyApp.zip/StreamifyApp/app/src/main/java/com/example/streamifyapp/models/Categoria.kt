package com.example.streamifyapp.models
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Categoria (val id: Int, val nombre: String, val imageId: Int) : Parcelable
