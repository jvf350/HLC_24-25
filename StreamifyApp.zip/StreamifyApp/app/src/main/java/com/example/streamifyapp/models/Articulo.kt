package com.example.streamifyapp.models
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Articulo (val id: Int,
                val nombre: String,
                val categoriaId: Int,
                val descripcion: String,
                val valoracion: Float,
                val imageId: Int): Parcelable
